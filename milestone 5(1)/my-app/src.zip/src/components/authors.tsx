import React, { Component } from "react";
 
class Authors extends Component {
  render() {
    return (
        <div>
        <table id="tableAuthor">
<tr>
<th>Author</th>
</tr>

    <td>Vivek</td>
</table></div>
    )}}
    export default Authors;