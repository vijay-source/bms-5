import { Carousel } from "react-bootstrap";

function Home(props: any) {
  return (
    <div>
      <div className="carousel-div">
        <Carousel>
          <Carousel.Item>
            <div className="img-div-carousel">
              <img
                className="d-block w-100 carousel-img"
                src="https://dogtrainingobedienceschool.com/pic/859565_full-so-many-books-so-little-time-quotes-so-many-books-so-little-time-quote-by-frank-zappa-page-3.jpg"
                alt="First slide"
              />
            </div>
           
          </Carousel.Item>
          <Carousel.Item>
            <div className="img-div-carousel">
              <img
                className="d-block w-100 carousel-img"
                src="https://wallpapercave.com/wp/wp1955025.jpg"
                alt="Second slide"
              />
            </div>
          </Carousel.Item>
          <Carousel.Item>
            <div className="img-div-carousel">
              <img
                className="d-block w-100 carousel-img"
                src="https://quotefancy.com/media/wallpaper/3840x2160/216320-Epictetus-Quote-Books-are-the-training-weights-of-the-mind.jpg"
                alt="Third slide"
              />
            </div>
          </Carousel.Item>
          <Carousel.Item>
            <div className="img-div-carousel">
              <img
                className="d-block w-100 carousel-img"
                src="https://quotefancy.com/media/wallpaper/3840x2160/15456-Francis-Bacon-Quote-Some-books-should-be-tasted-some-devoured-but.jpg"
                alt="Fourth slide"
              />
            </div>
          </Carousel.Item>
          <Carousel.Item>
            <div className="img-div-carousel">
              <img
                className="d-block w-100 carousel-img"
                src="https://quotefancy.com/media/wallpaper/3840x2160/4090-George-R-R-Martin-Quote-A-mind-needs-books-as-a-sword-needs-a.jpg"
                alt="Fifth slide"
              />
            </div>
          </Carousel.Item>
          <Carousel.Item>
            <div className="img-div-carousel">
              <img
                className="d-block w-100 carousel-img"
                src="https://4kwallpaper.wiki/wp-content/uploads/2019/09/113111.jpg"
                alt="Sixth slide"
              />
            </div>
          </Carousel.Item>
          <Carousel.Item>
            <div className="img-div-carousel">
              <img
                className="d-block w-100 carousel-img"
                src="https://pbs.twimg.com/media/EzXfRR8VEAcxNO9.jpg"
                alt="Seventh slide"
              />
            </div>
          </Carousel.Item>
        </Carousel>
      </div>
    </div>
  );
}

export default Home;
